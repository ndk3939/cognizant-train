﻿
$i =8 
While ($i -le 96) 
{
	$i 
	$i +=8
}