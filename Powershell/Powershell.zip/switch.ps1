﻿$value = 3
Switch ($value)
{
1 { "Number 1" }
2 { "Number 2" }
3 { "Number 3223324343" }
}
