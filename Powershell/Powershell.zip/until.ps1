﻿
$i = 7
$b = $i
$a = 1
do {
 $b
 $i 
 $i +=7 
} 
until ($i -gt 85)