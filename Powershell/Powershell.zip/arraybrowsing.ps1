﻿for($counter = 0; $counter -lt $myArray.Count; $counter++) 
{
	$sum += $myArray[$counter]
	iF($counter -eq ($myarray.count)-1)
	{
		$SUM
	}
}